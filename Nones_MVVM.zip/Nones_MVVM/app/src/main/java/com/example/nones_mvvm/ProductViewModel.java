package com.example.nones_mvvm;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

public class ProductViewModel extends ViewModel {
    MutableLiveData<List<Product>> products = new MutableLiveData<>();
    public MutableLiveData<List<Product>> getProducts() {
        if (products.getValue() == null) {
            loadData();
        }
        return products;
    }

    private void loadData() {
        List<Product> list = new ArrayList<>();
        list.add(new Product("Laptop", 45000));
        list.add(new Product("Phone", 20000));
        list.add(new Product("Headphones", 2500));

        products.setValue(list);
    }
}